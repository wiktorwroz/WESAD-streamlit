# 🧠 WESAD Streamlit App - Instrukcja

## 📦 KROK 1: Zainstaluj biblioteki

Otwórz Terminal (lub PowerShell na Windows) w tym folderze i wpisz:

```bash
# Mac/Linux:
pip3 install -r requirements.txt

# Windows:
pip install -r requirements.txt
```

## 🚀 KROK 2: Uruchom aplikację

W tym samym Terminalu wpisz:

```bash
streamlit run wesad_full_pro_streamlit_app.py
```

Aplikacja automatycznie otworzy się w przeglądarce pod adresem: **http://localhost:8501**

## ⚠️ Jeśli coś nie działa:

### Problem: "command not found: streamlit"
```bash
pip3 install streamlit
```

### Problem: "No module named 'pandas'"
```bash
pip3 install pandas numpy scikit-learn matplotlib seaborn streamlit
```

### Problem: "File not found"
- Upewnij się, że jesteś w folderze `wesad_streamlit_package`
- Sprawdź czy wszystkie pliki są w tym folderze:
  - ✅ wesad_full_pro_streamlit_app.py
  - ✅ wesad_features_full.csv
  - ✅ results/ (folder)

## 📝 Szybka wersja (wszystko w jednej komendzie):

```bash
pip3 install -r requirements.txt && streamlit run wesad_full_pro_streamlit_app.py
```

## 🎯 Ważne:

- **Wszystkie pliki muszą być w tym samym folderze!**
- **Nie zmieniaj nazw plików ani folderów!**
- **Uruchom aplikację z tego samego folderu gdzie są pliki!**
