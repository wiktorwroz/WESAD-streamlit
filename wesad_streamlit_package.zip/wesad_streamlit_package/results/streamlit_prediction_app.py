import streamlit as st
import pandas as pd
import numpy as np
import pickle
import json
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns

# Konfiguracja strony
st.set_page_config(
    page_title="WESAD Emotion Prediction",
    page_icon="🧠",
    layout="wide"
)

# Tytuł aplikacji
st.title("🧠 Interaktywna Predykcja Emocji - WESAD Dataset")
st.markdown("---")

# Funkcja do automatycznego wyszukiwania folderu results
def get_results_dir():
    """Automatycznie wykrywa lokalizację folderu results"""
    # 1. Katalog gdzie jest skrypt (najbardziej niezawodne)
    try:
        script_dir = Path(__file__).parent.resolve()
        if (script_dir / "analysis_results.json").exists():
            return script_dir
    except (NameError, AttributeError):
        pass
    
    # 2. Obecny katalog (jeśli uruchomiono z folderu results)
    current_dir = Path.cwd()
    if (current_dir / "analysis_results.json").exists():
        return current_dir
    
    # 3. Folder results w obecnym katalogu
    results_in_current = current_dir / "results"
    if results_in_current.exists() and (results_in_current / "analysis_results.json").exists():
        return results_in_current
    
    # 4. Folder results względem katalogu skryptu
    try:
        script_results = Path(__file__).parent.parent / "results"
        if script_results.exists() and (script_results / "analysis_results.json").exists():
            return script_results
    except (NameError, AttributeError):
        pass
    
    # Jeśli nic nie znaleziono, zwróć katalog skryptu lub obecny katalog
    try:
        return Path(__file__).parent.resolve()
    except (NameError, AttributeError):
        return current_dir

# Funkcja do wczytania modelu i scalera
@st.cache_resource
def load_model_and_scaler():
    """Wczytuje najlepszy model i scaler z plików"""
    results_dir = get_results_dir()
    
    # Wczytaj analysis_results.json aby znaleźć najlepszy model
    results_file = results_dir / "analysis_results.json"
    if not results_file.exists():
        st.error(f"❌ Nie znaleziono pliku analysis_results.json")
        st.error(f"Szukam w: {results_dir.absolute()}")
        
        # Sprawdź inne możliwe lokalizacje
        with st.expander("🔍 Diagnostyka - sprawdzam możliwe lokalizacje"):
            check_paths = [
                Path.cwd(),
                Path.cwd() / "results",
            ]
            try:
                check_paths.append(Path(__file__).parent)
                check_paths.append(Path(__file__).parent.parent / "results")
            except:
                pass
            
            for check_path in check_paths:
                json_path = check_path / "analysis_results.json"
                st.write(f"- {check_path.absolute()}: {'✅ ISTNIEJE' if json_path.exists() else '❌ brak'}")
                if json_path.exists():
                    st.success(f"   Znaleziono! Plik: {json_path.absolute()}")
        
        st.info(f"💡 Upewnij się, że uruchomiłeś komórkę 28 z notebooka, która generuje pliki!")
        st.stop()
    
    with open(results_file, 'r', encoding='utf-8') as f:
        analysis_results = json.load(f)
    
    best_model_name = analysis_results['best_model']['name']
    
    # Wczytaj model (zapisz go w komórce 28)
    model_file = results_dir / f"best_model_{best_model_name.lower()}.pkl"
    if not model_file.exists():
        st.error(f"❌ Nie znaleziono pliku modelu: {model_file}")
        st.info("💡 Upewnij się, że uruchomiłeś komórkę 28, która zapisuje model!")
        st.stop()
    
    with open(model_file, 'rb') as f:
        model = pickle.load(f)
    
    # Wczytaj scaler (jeśli został zapisany)
    scaler_file = results_dir / "scaler.pkl"
    scaler = None
    if scaler_file.exists():
        with open(scaler_file, 'rb') as f:
            scaler = pickle.load(f)
    
    # Wczytaj label encoder
    encoder_file = results_dir / "label_encoder.pkl"
    if not encoder_file.exists():
        st.error(f"❌ Nie znaleziono pliku label_encoder.pkl")
        st.stop()
    
    with open(encoder_file, 'rb') as f:
        label_encoder = pickle.load(f)
    
    # Wczytaj wszystkie nazwy cech (model został wytrenowany na wszystkich)
    n_features = analysis_results['data_info']['n_features']
    all_feature_names = analysis_results.get('feature_names', [f'feature_{i}' for i in range(n_features)])
    
    # Wczytaj top 10 cech (tylko do wyświetlenia)
    top_10_features = analysis_results.get('top_10_features', [])
    if top_10_features and len(top_10_features) == 10:
        display_features = top_10_features  # Tylko do wyświetlenia
    else:
        # Jeśli nie ma top 10, użyj pierwszych 10 z wszystkich cech
        display_features = all_feature_names[:10] if len(all_feature_names) >= 10 else all_feature_names
    
    return model, scaler, label_encoder, all_feature_names, display_features, best_model_name

# Wczytaj model i scaler
try:
    model, scaler, label_encoder, all_feature_names, display_features, best_model_name = load_model_and_scaler()
    st.sidebar.success(f"✅ Model załadowany: {best_model_name}")
except Exception as e:
    st.error(f"❌ Błąd podczas wczytywania modelu: {e}")
    st.stop()

# Sidebar z informacjami
with st.sidebar:
    st.header("📋 Informacje")
    st.write(f"**Model:** {best_model_name}")
    st.write(f"**Wyświetlane cechy:** {len(display_features)} (top 10 najważniejszych)")
    st.write(f"**Wszystkie cechy:** {len(all_feature_names)}")
    st.write(f"**Klasy:** {', '.join(label_encoder.classes_)}")
    st.markdown("---")
    st.header("ℹ️ Instrukcja")
    st.write("""
    1. Wybierz sposób wprowadzenia danych:
       - **Ręczne wprowadzenie**: Wpisz wartości cech ręcznie
       - **Wczytaj z pliku**: Wczytaj dane z pliku CSV
    2. Kliknij **"Oblicz predykcję"**
    3. Zobacz wynik i prawdopodobieństwa
    """)

# Automatyczne wczytanie losowej próbki z example_data.csv
@st.cache_data
def load_example_data():
    """Wczytuje przykładowe dane z example_data.csv"""
    results_dir = Path("results")
    example_file = results_dir / "example_data.csv"
    if example_file.exists():
        try:
            df = pd.read_csv(example_file)
            # Usuń kolumny z etykietami jeśli istnieją
            df = df.drop(columns=['true_label', 'true_label_encoded'], errors='ignore')
            return df
        except Exception as e:
            return None
    return None

# Wczytaj przykładowe dane
example_data = load_example_data()

# Główna sekcja aplikacji
st.header("📊 Wprowadź dane do predykcji")

# Automatycznie wczytaj losową próbkę jeśli example_data jest dostępne
if example_data is not None and len(example_data) > 0:
    # Wybierz losową próbkę
    if 'random_sample' not in st.session_state:
        import random
        random_idx = random.randint(0, len(example_data) - 1)
        st.session_state['random_sample'] = example_data.iloc[[random_idx]].copy()
        st.session_state['random_idx'] = random_idx
    
    # Wyświetl aktualną próbkę (tylko top 10 cech)
    st.subheader("📋 Losowa próbka z danych testowych (top 10 najważniejszych cech)")
    if all(f in st.session_state['random_sample'].columns for f in display_features):
        st.dataframe(st.session_state['random_sample'][display_features], use_container_width=True)
    else:
        st.dataframe(st.session_state['random_sample'], use_container_width=True)
    
    # Przycisk do losowania nowej próbki
    if st.button("🎲 Losuj nową próbkę", use_container_width=False):
        import random
        random_idx = random.randint(0, len(example_data) - 1)
        st.session_state['random_sample'] = example_data.iloc[[random_idx]].copy()
        st.session_state['random_idx'] = random_idx
        st.rerun()
    
    # Użyj losowej próbki jako danych wejściowych (wszystkie cechy dla modelu)
    feature_values = st.session_state['random_sample'].copy() if len(st.session_state['random_sample']) > 0 else None
    
    # Przycisk PREDYKCJA na dole
    st.markdown("---")
    if st.button("🔮 PREDYKCJA", type="primary", use_container_width=True, key="prediction_button"):
        if feature_values is not None:
            try:
                # Przygotuj dane - użyj WSZYSTKICH cech (model został wytrenowany na wszystkich)
                # Uzupełnij brakujące cechy wartościami 0.0
                full_feature_vector = pd.DataFrame(0.0, index=[0], columns=all_feature_names)
                for feat in all_feature_names:
                    if feat in feature_values.columns:
                        full_feature_vector[feat] = feature_values[feat].values[0]
                
                # Skaluj dane (jeśli scaler jest dostępny)
                if scaler is not None:
                    X_scaled = scaler.transform(full_feature_vector)
                else:
                    X_scaled = full_feature_vector.values
                
                # Predykcja
                predictions = model.predict(X_scaled)
                probabilities = model.predict_proba(X_scaled)
                
                # Wyświetl wyniki
                st.header("🎯 Wyniki predykcji")
                
                pred_label = label_encoder.inverse_transform([predictions[0]])[0]
                
                # Wyświetl główny wynik
                col1, col2, col3 = st.columns([1, 2, 1])
                
                with col2:
                    if pred_label == "emotion":
                        st.success(f"## 🎭 Wynik: **{pred_label.upper()}**")
                    else:
                        st.info(f"## 😌 Wynik: **{pred_label.upper()}**")
                
                # Prawdopodobieństwa
                st.subheader("📊 Prawdopodobieństwa:")
                
                prob_dict = {}
                for i, class_name in enumerate(label_encoder.classes_):
                    prob_dict[class_name] = probabilities[0][i]
                
                # Wykres słupkowy prawdopodobieństw
                fig, ax = plt.subplots(figsize=(10, 6))
                classes = list(prob_dict.keys())
                probs = list(prob_dict.values())
                colors = ['#ff6b6b' if c == 'emotion' else '#4ecdc4' for c in classes]
                
                bars = ax.bar(classes, probs, color=colors, alpha=0.7, edgecolor='black', linewidth=2)
                ax.set_ylabel('Prawdopodobieństwo', fontsize=12, fontweight='bold')
                ax.set_xlabel('Klasa', fontsize=12, fontweight='bold')
                ax.set_title('Prawdopodobieństwa predykcji', fontsize=14, fontweight='bold')
                ax.set_ylim(0, 1)
                ax.grid(True, alpha=0.3, axis='y')
                
                # Dodaj wartości na słupkach
                for bar, prob_val in zip(bars, probs):
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                           f'{prob_val:.2%}',
                           ha='center', va='bottom', fontsize=11, fontweight='bold')
                
                plt.tight_layout()
                st.pyplot(fig)
                
                # Tabela z prawdopodobieństwami
                prob_df = pd.DataFrame([prob_dict])
                st.dataframe(prob_df.T.rename(columns={0: 'Prawdopodobieństwo'}), use_container_width=True)
                
            except Exception as e:
                st.error(f"❌ Błąd podczas predykcji: {e}")
                st.exception(e)
else:
    # Jeśli nie ma example_data, pokaż standardowy interfejs
    st.info("💡 Wczytaj dane ręcznie lub z pliku CSV")
    
    input_method = st.radio(
        "Wybierz sposób wprowadzenia danych:",
        ["Ręczne wprowadzenie", "Wczytaj z pliku CSV"],
        horizontal=True
    )
    
    input_data = None
    feature_values = None
    
    if input_method == "Ręczne wprowadzenie":
        st.subheader("Wprowadź wartości cech (top 10 najważniejszych)")
        
        # Podziel cechy na grupy dla lepszej organizacji
        n_display_features = len(display_features)
        
        # Utwórz kolumny dla lepszego układu
        col1, col2 = st.columns(2)
        
        feature_dict = {}
        
        with col1:
            st.write("**Grupa 1:**")
            for i, feature_name in enumerate(display_features[:n_display_features//2]):
                feature_dict[feature_name] = st.number_input(
                    feature_name,
                    value=0.0,
                    step=0.01,
                    key=f"feature_{i}"
                )
        
        with col2:
            st.write("**Grupa 2:**")
            for i, feature_name in enumerate(display_features[n_display_features//2:], start=n_display_features//2):
                feature_dict[feature_name] = st.number_input(
                    feature_name,
                    value=0.0,
                    step=0.01,
                    key=f"feature_{i}"
                )
        
        # Konwertuj na DataFrame (tylko top 10 cech)
        feature_values = pd.DataFrame([feature_dict])
    
    else:
        st.subheader("Wczytaj dane z pliku CSV")
        uploaded_file = st.file_uploader(
            "Wybierz plik CSV",
            type=['csv'],
            help="Plik CSV powinien zawierać kolumny z nazwami cech"
        )
        
        if uploaded_file is not None:
            try:
                input_data = pd.read_csv(uploaded_file)
                st.success(f"✅ Wczytano plik: {uploaded_file.name}")
                st.write(f"**Liczba wierszy:** {len(input_data)}")
                st.write(f"**Liczba kolumn:** {len(input_data.columns)}")
                
                # Sprawdź czy wszystkie wymagane cechy są obecne (tylko top 10 do wyświetlenia)
                missing_features = set(display_features) - set(input_data.columns)
                if missing_features:
                    st.warning(f"⚠️ Brakujące cechy (top 10): {', '.join(missing_features)}")
                    st.info("💡 Użyj wartości domyślnych (0.0) dla brakujących cech")
                
                # Wybierz wiersz do predykcji
                if len(input_data) > 1:
                    row_index = st.selectbox(
                        "Wybierz wiersz do predykcji:",
                        range(len(input_data)),
                        format_func=lambda x: f"Wiersz {x+1}"
                    )
                    feature_values = input_data.iloc[[row_index]]
                else:
                    feature_values = input_data
                
                # Wyświetl podgląd danych
                st.subheader("Podgląd danych:")
                st.dataframe(feature_values, use_container_width=True)
            except Exception as e:
                st.error(f"❌ Błąd podczas wczytywania pliku: {e}")
                feature_values = None

# Przycisk do predykcji
if feature_values is not None:
    if st.button("🔮 Oblicz predykcję", type="primary", use_container_width=True):
        try:
            # Przygotuj dane
            # Uzupełnij brakujące cechy wartościami domyślnymi (używamy WSZYSTKICH cech)
            full_feature_vector = pd.DataFrame(0.0, index=[0], columns=all_feature_names)
            for feat in all_feature_names:
                if feat in feature_values.columns:
                    full_feature_vector[feat] = feature_values[feat].values[0]
            
            # Uporządkuj kolumny zgodnie z kolejnością all_feature_names
            feature_values = full_feature_vector
            
            # Skaluj dane (jeśli scaler jest dostępny)
            if scaler is not None:
                X_scaled = scaler.transform(feature_values)
            else:
                X_scaled = feature_values.values
            
            # Predykcja
            predictions = model.predict(X_scaled)
            probabilities = model.predict_proba(X_scaled)
            
            # Wyświetl wyniki
            st.header("🎯 Wyniki predykcji")
            
            # Wynik dla każdego wiersza
            for idx, (pred, prob) in enumerate(zip(predictions, probabilities)):
                pred_label = label_encoder.inverse_transform([pred])[0]
                
                # Wyświetl główny wynik
                col1, col2, col3 = st.columns([1, 2, 1])
                
                with col2:
                    if pred_label == "emotion":
                        st.success(f"## 🎭 Wynik: **{pred_label.upper()}**")
                    else:
                        st.info(f"## 😌 Wynik: **{pred_label.upper()}**")
                
                # Prawdopodobieństwa
                st.subheader("📊 Prawdopodobieństwa:")
                
                prob_dict = {}
                for i, class_name in enumerate(label_encoder.classes_):
                    prob_dict[class_name] = prob[i]
                
                # Wykres słupkowy prawdopodobieństw
                fig, ax = plt.subplots(figsize=(10, 6))
                classes = list(prob_dict.keys())
                probs = list(prob_dict.values())
                colors = ['#ff6b6b' if c == 'emotion' else '#4ecdc4' for c in classes]
                
                bars = ax.bar(classes, probs, color=colors, alpha=0.7, edgecolor='black', linewidth=2)
                ax.set_ylabel('Prawdopodobieństwo', fontsize=12, fontweight='bold')
                ax.set_xlabel('Klasa', fontsize=12, fontweight='bold')
                ax.set_title(f'Prawdopodobieństwa predykcji - Wiersz {idx+1}', fontsize=14, fontweight='bold')
                ax.set_ylim(0, 1)
                ax.grid(True, alpha=0.3, axis='y')
                
                # Dodaj wartości na słupkach
                for bar, prob_val in zip(bars, probs):
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                           f'{prob_val:.2%}',
                           ha='center', va='bottom', fontsize=11, fontweight='bold')
                
                plt.tight_layout()
                st.pyplot(fig)
                
                # Tabela z prawdopodobieństwami
                prob_df = pd.DataFrame([prob_dict])
                st.dataframe(prob_df.T.rename(columns={0: 'Prawdopodobieństwo'}), use_container_width=True)
                
                # Szczegółowe informacje
                with st.expander("ℹ️ Szczegółowe informacje"):
                    st.write(f"**Predykcja:** {pred_label}")
                    st.write(f"**Pewność:** {max(prob):.2%}")
                    st.write(f"**Wszystkie prawdopodobieństwa:**")
                    for class_name, prob_val in prob_dict.items():
                        st.write(f"  - {class_name}: {prob_val:.2%}")
        
        except Exception as e:
            st.error(f"❌ Błąd podczas predykcji: {e}")
            st.exception(e)

# Sekcja z przykładowymi danymi
with st.expander("💡 Przykładowe dane"):
    st.write("""
    Możesz użyć przykładowych danych z testowego zbioru danych.
    Poniżej znajduje się przykład jednej próbki z danych testowych.
    """)
    
    if 'X_test' in globals() and len(X_test) > 0:
        # Wybierz losową próbkę z testowego zbioru
        sample_idx = 0  # Możesz zmienić na losową
        sample_data = X_test.iloc[[sample_idx]] if hasattr(X_test, 'iloc') else pd.DataFrame([X_test[sample_idx]])
        
        st.write("**Przykładowa próbka z danych testowych:**")
        st.dataframe(sample_data, use_container_width=True)
        
        # Pobierz prawdziwą etykietę
        if 'y_test' in globals():
            true_label = label_encoder.inverse_transform([y_test[sample_idx]])[0]
            st.write(f"**Prawdziwa etykieta:** {true_label}")
        
        # Przycisk do użycia przykładowych danych
        if st.button("📋 Użyj przykładowych danych"):
            feature_values = sample_data
            st.rerun()

# Stopka
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: gray;'>
    <p>WESAD Emotion Prediction App | Powered by Streamlit</p>
</div>
""", unsafe_allow_html=True)
